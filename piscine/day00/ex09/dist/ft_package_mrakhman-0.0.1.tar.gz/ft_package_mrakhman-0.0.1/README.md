# Package for 42 school project
Learn how to create python packages

How to create a package:
https://packaging.python.org/en/latest/tutorials/packaging-projects/

Commands:

# Creates dist folder with .whl and .gz
python -m build

Create account and create API key at https://test.pypi.org/account/register/

python -m twine upload --repository testpypi dist/*


